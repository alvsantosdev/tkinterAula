import tkinter as tk
from tkinter import ttk, messagebox
import mysql.connector


DB_CONFIG = {
    'host': 'localhost',
    'user': 'root',
    'password': '',
    'database': 'escola'
}



def conectar_db():
    try:
        conn = mysql.connector.connect(**DB_CONFIG)
        return conn
    except mysql.connector.Error as err:
        messagebox.showerror("Erro de Conexão", f"Não foi possível conectar ao banco de dados: {err}")
        return None


def criar_tabela_alunos():
    conn = conectar_db()
    if conn:
        cursor = conn.cursor()
        try:
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS alunos (
                    id INT AUTO_INCREMENT PRIMARY KEY,
                    nome VARCHAR(100) NOT NULL,
                    idade INT,
                    curso VARCHAR(100)
                )
            """)
            conn.commit()
            print("Tabela 'alunos' verificada/criada com sucesso.")
        except mysql.connector.Error as err:
            messagebox.showerror("Erro SQL", f"Erro ao criar/verificar tabela: {err}")
        finally:
            cursor.close()
            conn.close()


def inserir_aluno(nome, data, genero):
    conn = conectar_db()
    if conn:
        cursor = conn.cursor()
        try:
            sql = "INSERT INTO alunos (nome_aluno, data_nascimento, genero) VALUES (%s, %s, %s)"
            cursor.execute(sql, (nome, data, genero))
            conn.commit()
            messagebox.showinfo("Sucesso", "Aluno cadastrado com sucesso!")
            return True
        except mysql.connector.Error as err:
            messagebox.showerror("Erro ao Cadastrar", f"Erro ao inserir aluno: {err}")
            return False
        finally:
            cursor.close()
            conn.close()


def buscar_alunos():
    conn = conectar_db()
    if conn:
        cursor = conn.cursor()
        try:
            cursor.execute("SELECT id, nome_aluno, data_nascimento, genero FROM alunos")
            alunos = cursor.fetchall()
            return alunos
        except mysql.connector.Error as err:
            messagebox.showerror("Erro ao Buscar", f"Erro ao buscar alunos: {err}")
            return []
        finally:
            cursor.close()
            conn.close()



class Aplicacao:
    def __init__(self, master):
        self.master = master
        master.title("Sistema de Cadastro de Alunos")
        master.geometry("800x600")
        master.resizable(True, True)

        criar_tabela_alunos()


        self.nome_var = tk.StringVar()
        self.idade_var = tk.StringVar()
        self.curso_var = tk.StringVar()


        self.criar_menu()


        self.frame_cadastro = ttk.LabelFrame(master, text="Cadastro de Alunos", padding=(20, 10))
        self.frame_cadastro.pack(pady=10, padx=20, fill="x")

        self.frame_tabela = ttk.LabelFrame(master, text="Alunos Cadastrados", padding=(20, 10))
        self.frame_tabela.pack(pady=10, padx=20, fill="both", expand=True)

        self.criar_formulario_cadastro()

        self.criar_treeview_alunos()

        self.carregar_alunos_treeview()

    def criar_menu(self):
        menubar = tk.Menu(self.master)
        self.master.config(menu=menubar)

        modulos_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="Módulos", menu=modulos_menu)
        modulos_menu.add_command(label="Alunos", command=self.mostrar_modulo_alunos)
        modulos_menu.add_command(label="Turmas (Exemplo)",
                                 command=self.mostrar_modulo_turmas)

        ajuda_menu = tk.Menu(menubar, tearoff=0)
        menubar.add_cascade(label="Ajuda", menu=ajuda_menu)
        ajuda_menu.add_command(label="Sobre", command=self.mostrar_sobre)

    def criar_formulario_cadastro(self):

        ttk.Label(self.frame_cadastro, text="Nome:").grid(row=0, column=0, padx=5, pady=5, sticky="w")
        ttk.Entry(self.frame_cadastro, textvariable=self.nome_var, width=40).grid(row=0, column=1, padx=5, pady=5,
                                                                                  sticky="ew")

        ttk.Label(self.frame_cadastro, text="data_nascimento:").grid(row=1, column=0, padx=5, pady=5, sticky="w")
        ttk.Entry(self.frame_cadastro, textvariable=self.idade_var, width=40).grid(row=1, column=1, padx=5, pady=5,
                                                                                   sticky="ew")

        ttk.Label(self.frame_cadastro, text="genero:").grid(row=2, column=0, padx=5, pady=5, sticky="w")
        ttk.Entry(self.frame_cadastro, textvariable=self.curso_var, width=40).grid(row=2, column=1, padx=5, pady=5,
                                                                                   sticky="ew")

        ttk.Button(self.frame_cadastro, text="Cadastrar", command=self.cadastrar_aluno).grid(row=3, column=0,
                                                                                             columnspan=2, pady=10)

        self.frame_cadastro.grid_columnconfigure(1, weight=1)

    def criar_treeview_alunos(self):

        colunas = ("ID", "Nome", "data_nascimento", "genero")
        self.tree = ttk.Treeview(self.frame_tabela, columns=colunas, show="headings")

        for col in colunas:
            self.tree.heading(col, text=col, anchor="center")
            self.tree.column(col, width=100, anchor="center")


        self.tree.column("ID", width=50)
        self.tree.column("Nome", width=200)
        self.tree.column("data_nascimento", width=70)
        self.tree.column("genero", width=150)

        scrollbar_y = ttk.Scrollbar(self.frame_tabela, orient="vertical", command=self.tree.yview)
        self.tree.configure(yscrollcommand=scrollbar_y.set)

        self.tree.pack(side="left", fill="both", expand=True)
        scrollbar_y.pack(side="right", fill="y")

    def carregar_alunos_treeview(self):

        for item in self.tree.get_children():
            self.tree.delete(item)

        alunos = buscar_alunos()
        for aluno in alunos:
            self.tree.insert("", "end", values=aluno)

    def cadastrar_aluno(self):
        nome = self.nome_var.get().strip()
        idade_str = self.idade_var.get().strip()
        curso = self.curso_var.get().strip()

        if not nome or not idade_str or not curso:
            messagebox.showwarning("Campos Vazios", "Por favor, preencha todos os campos.")
            return

        try:
            idade = int(idade_str)
            if idade <= 0:
                raise ValueError
        except ValueError:
            messagebox.showerror("Erro de Idade", "A idade deve ser um número inteiro positivo.")
            return

        if inserir_aluno(nome, idade, curso):
            self.limpar_campos_cadastro()
            self.carregar_alunos_treeview()

    def limpar_campos_cadastro(self):
        self.nome_var.set("")
        self.idade_var.set("")
        self.curso_var.set("")

    def mostrar_modulo_alunos(self):
        messagebox.showinfo("Módulo", "Você está no módulo de Alunos.")

        self.frame_cadastro.pack(pady=10, padx=20, fill="x")
        self.frame_tabela.pack(pady=10, padx=20, fill="both", expand=True)
        self.carregar_alunos_treeview()

    def mostrar_modulo_turmas(self):
        messagebox.showinfo("Módulo", "Este seria o módulo de Turmas.")

        self.frame_cadastro.pack_forget()
        self.frame_tabela.pack_forget()

    def mostrar_sobre(self):
        integrantes = "• Integrante 1: [Seu Nome]\n• Integrante 2: [Nome do Colega]"
        titulo_projeto = "Sistema de Cadastro de Alunos"
        descricao = ("Esta aplicação permite cadastrar alunos e visualizar seus dados em uma tabela, "
                     "utilizando Tkinter para a interface gráfica e MySQL para o banco de dados.")
        info = f"Integrantes do Grupo:\n{integrantes}\n\nTítulo do Projeto:\n{titulo_projeto}\n\nDescrição da Aplicação:\n{descricao}"
        messagebox.showinfo("Sobre a Aplicação", info)


# --- Ponto de Entrada da Aplicação ---
if __name__ == "__main__":
    root = tk.Tk()
    app = Aplicacao(root)
    root.mainloop()